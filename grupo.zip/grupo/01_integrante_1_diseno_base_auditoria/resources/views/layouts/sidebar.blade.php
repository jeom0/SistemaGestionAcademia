<aside class="w-72 bg-white border-r border-outline flex flex-col h-screen sticky top-0">
    <!-- User Profile Section -->
    <div class="px-8 py-6 flex items-center gap-4">
        <div class="w-12 h-12 rounded-full bg-slate-200 overflow-hidden flex-shrink-0 border border-outline shadow-sm">
            @if(auth()->user()->avatar)
                <img src="{{ asset('storage/' . auth()->user()->avatar) }}" alt="Avatar" class="w-full h-full object-cover">
            @else
                <img src="https://ui-avatars.com/api/?name={{ urlencode(auth()->user()->name) }}&background=006837&color=fff" alt="Avatar" class="w-full h-full object-cover">
            @endif
        </div>
        <div class="flex flex-col">
            <span class="text-sm font-bold text-secondary leading-tight">{{ auth()->user()->name }}</span>
            <span class="text-[10px] font-medium text-on-surface-variant uppercase tracking-wider">
                {{ auth()->user()->role === 'root' ? 'Administrador Root' : ucfirst(auth()->user()->role) }}
            </span>
        </div>
    </div>

    <!-- Navigation Menu -->
    <nav class="flex-1 px-4 py-4 overflow-y-auto">
        <ul class="flex flex-col gap-1">
            <li>
                <a href="{{ route('dashboard') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all {{ (request()->routeIs('dashboard') || request()->routeIs('*.dashboard')) ? 'bg-primary-light text-primary font-bold shadow-sm' : 'text-on-surface-variant hover:bg-surface-variant hover:text-secondary' }}">
                    <span class="material-symbols-outlined text-[22px] {{ (request()->routeIs('dashboard') || request()->routeIs('*.dashboard')) ? 'fill-1' : '' }}">grid_view</span>
                    <span class="text-sm">Dashboard</span>
                </a>
            </li>

            <li>
                <a href="{{ route('movements.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all {{ request()->routeIs('movements.*') ? 'bg-primary-light text-primary font-bold shadow-sm' : 'text-on-surface-variant hover:bg-surface-variant hover:text-secondary' }}">
                    <span class="material-symbols-outlined text-[22px] {{ request()->routeIs('movements.*') ? 'fill-1' : '' }}">payments</span>
                    <span class="text-sm">Movimientos</span>
                </a>
            </li>

            <li>
                <a href="{{ route('accounts.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all {{ request()->routeIs('accounts*') ? 'bg-primary-light text-primary font-bold shadow-sm' : 'text-on-surface-variant hover:bg-surface-variant hover:text-secondary' }}">
                    <span class="material-symbols-outlined text-[22px] {{ request()->routeIs('accounts*') ? 'fill-1' : '' }}">account_balance</span>
                    <span class="text-sm">Cuentas</span>
                </a>
            </li>

            @if(auth()->user()->isRoot())
            <li>
                <a href="{{ route('root.users.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all {{ request()->routeIs('root.users.*') ? 'bg-primary-light text-primary font-bold shadow-sm' : 'text-on-surface-variant hover:bg-surface-variant hover:text-secondary' }}">
                    <span class="material-symbols-outlined text-[22px] {{ request()->routeIs('root.users.*') ? 'fill-1' : '' }}">group</span>
                    <span class="text-sm">Usuarios</span>
                </a>
            </li>
            @endif

            <li>
                <a href="{{ route('reports.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all {{ request()->routeIs('reports*') ? 'bg-primary-light text-primary font-bold shadow-sm' : 'text-on-surface-variant hover:bg-surface-variant hover:text-secondary' }}">
                    <span class="material-symbols-outlined text-[22px] {{ request()->routeIs('reports*') ? 'fill-1' : '' }}">description</span>
                    <span class="text-sm">Reportes</span>
                </a>
            </li>

            <li>
                <a href="{{ route('profile.edit') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all {{ request()->routeIs('profile*') ? 'bg-primary-light text-primary font-bold shadow-sm' : 'text-on-surface-variant hover:bg-surface-variant hover:text-secondary' }}">
                    <span class="material-symbols-outlined text-[22px] {{ request()->routeIs('profile*') ? 'fill-1' : '' }}">settings</span>
                    <span class="text-sm">Configuración</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- Bottom Actions -->
    <div class="px-4 py-8 border-t border-outline">
        <a href="https://wa.me/573000000000" target="_blank" class="flex items-center gap-3 px-4 py-3 rounded-xl text-on-surface-variant hover:bg-emerald-50 hover:text-[#006837] transition-all mb-2 group">
            <span class="material-symbols-outlined text-[22px] group-hover:scale-110 transition-transform">help</span>
            <span class="text-sm font-bold">Ayuda WhatsApp</span>
        </a>
        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button type="submit" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-on-surface-variant hover:bg-red-50 hover:text-red-600 transition-all">
                <span class="material-symbols-outlined text-[22px]">logout</span>
                <span class="text-sm font-medium">Cerrar sesión</span>
            </button>
        </form>
    </div>
</aside>
